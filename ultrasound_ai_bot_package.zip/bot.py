
import os
import logging
from aiogram import Bot, Dispatcher, types
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import Message
from aiogram import Router
from aiogram.enums import ParseMode
from PIL import Image

from ultrasound_ai_bot import load_fetalclip_model, analyze_image_with_fetalclip

BOT_TOKEN = os.getenv("BOT_TOKEN")

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())
router = Router()
dp.include_router(router)

# Загружаем модель FetalCLIP при запуске
fetalclip_model = load_fetalclip_model()

@router.message(lambda m: m.text in ["/start", "/help"])
async def start_handler(message: Message):
    await message.answer("Привет! Отправь мне УЗИ изображение (jpg/png), и я выполню ИИ-анализ.")

@router.message(lambda m: m.photo)
async def handle_photo(message: Message):
    try:
        photo = message.photo[-1]
        file = await bot.get_file(photo.file_id)
        file_path = file.file_path
        downloaded_file = await bot.download_file(file_path)

        filename = f"temp_{message.from_user.id}.jpg"
        with open(filename, "wb") as f:
            f.write(downloaded_file.read())

        # Анализ изображения
        result = analyze_image_with_fetalclip(fetalclip_model, filename)
        os.remove(filename)

        await message.answer(f"ИИ-анализ завершён. Результат модели:
{result}")
    except Exception as e:
        await message.answer(f"Ошибка при анализе изображения: {str(e)}")

@router.message()
async def fallback(message: Message):
    await message.answer("Пожалуйста, отправьте изображение УЗИ.")

if __name__ == "__main__":
    import asyncio
    async def run():
        await dp.start_polling(bot)
    asyncio.run(run())
