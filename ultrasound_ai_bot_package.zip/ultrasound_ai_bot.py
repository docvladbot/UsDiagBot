
import os
import torch
from PIL import Image
from torchvision import transforms, io

# === Загрузка модели FetalCLIP ===
def load_fetalclip_model():
    model = torch.hub.load('biomedia-mbzuai/fetalclip', 'fetalclip', pretrained=True)
    model.eval()
    return model

# === Загрузка модели FetalNet ===
def load_fetalnet_model():
    # Здесь пример заглушки — модель должна быть загружена вручную из репозитория
    model = torch.load("FetalNet_model.pth", map_location=torch.device('cpu'))
    model.eval()
    return model

# === Обработка изображения через FetalCLIP ===
def analyze_image_with_fetalclip(model, image_path):
    image = Image.open(image_path).convert("RGB")
    preprocess = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
    ])
    input_tensor = preprocess(image).unsqueeze(0)
    with torch.no_grad():
        output = model(input_tensor)
    return output

# === Обработка видео через torchvision и FetalNet ===
def analyze_video_with_fetalnet(model, video_path):
    video, _, _ = io.read_video(video_path, pts_unit='sec')
    return {"prediction": "Видео обработано. Добавьте модельный анализ."}
