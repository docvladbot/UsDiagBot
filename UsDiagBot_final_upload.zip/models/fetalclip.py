
import torch.nn as nn

class FetalCLIP(nn.Module):
    def __init__(self):
        super(FetalCLIP, self).__init__()
        self.dummy = nn.Identity()

    def forward(self, x):
        return self.dummy(x)
